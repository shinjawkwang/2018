#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
	int a = atoi(argv[1]);
	int b = atoi(argv[2]);
	printf("sum is %d\n", a+b);
	return 0;
}
